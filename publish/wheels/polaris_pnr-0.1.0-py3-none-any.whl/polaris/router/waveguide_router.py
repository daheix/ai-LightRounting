"""波导约束布线器（Task 11）。

实现网格布线（A*/Lee 基线）+ 弯曲半径约束 + 波导间距约束 + 交叉最小化
+ 等长路径约束（MZI 臂、差分对）+ S 弯/弯曲路径生成。

方法参考（方案检索，见项目规则 1.1）：
- A* 搜索算法（经典网格寻路，Hart, Nilsson & Raphael 1968）
  https://en.wikipedia.org/wiki/A*_search_algorithm
- Cheng et al., NeurIPS 2022 一次性生成式布线模型（SJTU+华为）
  https://openreview.net/pdf?id=uNYqDfPEDD8
- LiDAR (ISPD 2025) 曲线感知 A* 光波导详细布线（grid-based curvy-aware A*）
  https://dl.acm.org/doi/pdf/10.1145/3698364.3705355
- LiDAR 2.0 分层曲线波导布线（Manhattan/非 Manhattan 状态、弯曲半径约束）
  https://arxiv.org/html/2505.17239v2
- Jump Point Search (JPS) 网格寻路剪枝（Harabor & Grastien 2011）
  https://cdn.aaai.org/ojs/7994/7994-13-11522-1-2-20201228.pdf
- Red Blob Games A* 实现优化（整数编码 + 启发式 + tie-breaker）
  https://www.redblobgames.com/pathfinding/a-star/implementation.html
- 欧拉弯曲（clothoid）平滑过渡，曲率线性变化降低弯曲损耗
  来源: Fujisawa et al., Opt. Express 25, 9150 (2017)
  https://opg.optica.org/oe/fulltext.cfm?uri=oe-25-8-9150
- Rizzo et al., Optics Letters 48(2), 215 (2023) 欧拉曲线提升 SOI 器件制造鲁棒性
  https://lightwave.ee.columbia.edu/sites/default/files/content/publications/2022/ol-48-2-215.pdf
- 弯曲半径约束：SOI 2-6μm / SiN 50-100μm（见 spec.md）

性能优化（止血后第一波A，目标 627ms→50ms）：
- 步骤1: 紧致启发式 + tie-breaker（Red Blob Games，预期 1.5-3x）
- 步骤2: 整数状态编码 + 障碍 numpy 统一（预期 2-4x）
- 步骤3: JPS-Bend 跳跃扩展（Harabor 2011，预期 5-15x）
"""

from __future__ import annotations

import heapq
import math
from dataclasses import dataclass, field

import numpy as np

# 从 path_geometry 重导出，保持向后兼容（规则 7.2：拆分后通过重导出保持接口不变）
# noqa: F401 表示这些导入是有意的重导出，供上层 `from polaris.router.waveguide_router import ...` 使用
from polaris.router.path_geometry import (  # noqa: F401
    arc_bend,
    check_min_spacing,
    count_crossings,
    equalize_length,
    euler_bend,
    path_length,
    path_loss,
    s_bend,
)

__all__ = [
    "GridRouter",
    "RouterConstraints",
    "WaveguidePath",
    "WaveguideRouter",
    "RouteConnectionConfig",
    "route_connection",
    "get_platform_constraints",
    "PLATFORM_CONSTRAINTS",
    # 重导出的几何工具（向后兼容）
    "arc_bend",
    "check_min_spacing",
    "count_crossings",
    "equalize_length",
    "euler_bend",
    "path_length",
    "path_loss",
    "s_bend",
]


@dataclass
class WaveguidePath:
    """一条波导路径（折线点序列 + 损耗 + 长度）。"""

    points: list[tuple[float, float]] = field(default_factory=list)
    length_um: float = 0.0
    loss_db: float = 0.0
    num_bends: int = 0
    num_crossings: int = 0

    def add_point(self, x: float, y: float) -> None:
        if self.points:
            x0, y0 = self.points[-1]
            self.length_um += math.hypot(x - x0, y - y0)
        self.points.append((x, y))


@dataclass
class RouterConstraints:
    """路由器几何约束（将 GridRouter 的约束参数打包，降低函数参数个数）。

    Attributes:
        min_bend_radius_um: 最小弯曲半径（μm）。
        min_spacing_um: 最小波导间距（μm）。
    """

    min_bend_radius_um: float = 5.0
    min_spacing_um: float = 1.0


# ---------------------------------------------------------------------------
# SubTask 11.1: A*/Lee 网格布线基线
# ---------------------------------------------------------------------------
class GridRouter:
    """A* 网格布线器（基线）。

    在栅格化画布上用 A* 搜索从起点到终点的最短曼哈顿路径，
    避开障碍（已放置器件/已布波导），并满足弯曲半径约束。

    性能优化注记：
    - ``_route_goal`` / ``_route_blocked`` 在 ``route()`` 期间作为实例属性缓存，
      使 ``_jump`` / ``_get_jump_successors`` 参数个数 ≤5（规则 7.1）。
      本类非线程安全（``route()`` 会临时修改 ``self.obstacle``），缓存模式可接受。
    """

    # 方向向量: 0=E(+x), 1=W(-x), 2=N(+y), 3=S(-y)
    _DIR_VECTORS = ((1, 0), (-1, 0), (0, 1), (0, -1))

    def __init__(
        self,
        grid_w: int,
        grid_h: int,
        grid_size: float = 1.0,
        constraints: RouterConstraints | None = None,
    ) -> None:
        cons = constraints or RouterConstraints()
        self.grid_w = grid_w
        self.grid_h = grid_h
        self.grid_size = grid_size
        self.min_bend_radius_um = cons.min_bend_radius_um
        # 弯曲半径对应的网格步数：
        # - min_bend_radius_um > 0：转弯前须直行 >= min_bend_steps 步（光波导约束）
        # - min_bend_radius_um <= 0：无弯曲约束（电金属布线），min_bend_steps=1 允许任意转弯
        if cons.min_bend_radius_um <= 0.0:
            self.min_bend_steps = 1
        else:
            self.min_bend_steps = max(2, int(round(cons.min_bend_radius_um / grid_size)))
        self.min_spacing_um = cons.min_spacing_um
        # 障碍栅格：0=可走，>0=障碍/占用
        self.obstacle: np.ndarray = np.zeros((grid_h, grid_w), dtype=np.int32)
        # route() 期间缓存的运行时上下文（降低 _jump/_get_jump_successors 参数个数）
        self._route_goal: tuple[int, int] = (0, 0)
        self._route_blocked: set[tuple[int, int]] = set()

    def add_obstacle(self, gx: int, gy: int, gw: int = 1, gh: int = 1) -> None:
        """标记障碍区域。"""
        x0 = max(0, gx)
        y0 = max(0, gy)
        x1 = min(self.grid_w, gx + gw)
        y1 = min(self.grid_h, gy + gh)
        self.obstacle[y0:y1, x0:x1] = 1

    def add_obstacle_box(self, xmin: float, ymin: float, xmax: float, ymax: float) -> None:
        """按画布坐标添加障碍盒。"""
        gx0 = max(0, int(xmin / self.grid_size))
        gy0 = max(0, int(ymin / self.grid_size))
        gx1 = min(self.grid_w, int(math.ceil(xmax / self.grid_size)))
        gy1 = min(self.grid_h, int(math.ceil(ymax / self.grid_size)))
        self.obstacle[gy0:gy1, gx0:gx1] = 1

    def _heuristic(self, a: tuple[int, int], b: tuple[int, int]) -> float:
        return abs(a[0] - b[0]) + abs(a[1] - b[1])

    def _heuristic_bend_aware(
        self, pos: tuple[int, int], goal: tuple[int, int], last_dir: int, straight: int
    ) -> float:
        """弯曲半径感知的紧致启发式（第一波A 步骤1）。

        在 Manhattan 距离基础上，若当前方向与到目标的主方向不一致，
        加上转弯前必须直行的步数下界（min_bend_steps - straight）。

        保持 admissible：只加"最少必须的额外步数"，不高估。
        来源: Red Blob Games, "Heuristics",
        http://theory.stanford.edu/~amitp/GameProgramming/Heuristics.html

        Args:
            pos: 当前网格位置 (x, y)。
            goal: 目标网格位置 (gx, gy)。
            last_dir: 当前方向编码（-1=无，0=E, 1=W, 2=N, 3=S）。
            straight: 当前方向已直行步数。

        Returns:
            启发式值（admissible，<= 真实最短路径代价）。
        """
        dx = goal[0] - pos[0]
        dy = goal[1] - pos[1]
        base = abs(dx) + abs(dy)
        if last_dir < 0 or self.min_bend_steps <= 1:
            return float(base)
        if self._dir_towards_goal(last_dir, dx, dy):
            return float(base)
        # 当前方向背离目标或垂直于目标方向，至少需要转弯一次
        # 转弯前还需直行 (min_bend_steps - straight) 步（若 straight < min_bend_steps）
        remaining = max(0, self.min_bend_steps - straight)
        return float(base + remaining)

    @staticmethod
    def _dir_towards_goal(direction: int, dx: int, dy: int) -> bool:
        """判断当前方向是否朝向目标（降低 _heuristic_bend_aware 圈复杂度，规则 7.3）。

        方向编码: 0=E(+x), 1=W(-x), 2=N(+y), 3=S(-y)
        """
        return (
            (direction == 0 and dx > 0)
            or (direction == 1 and dx < 0)
            or (direction == 2 and dy > 0)
            or (direction == 3 and dy < 0)
        )

    # ------------------------------------------------------------------
    # 整数状态编码（第一波A 步骤2，Red Blob Games 优化）
    # ------------------------------------------------------------------
    def _encode(self, x: int, y: int, d: int, s: int) -> int:
        """将 4-tuple 状态编码为单个 int，加速 dict 哈希。

        编码: state = ((y * grid_w + x) * 4 + (d+1)) * min_bend_steps + s
        d+1 是为了把 -1（无方向）映射到 0，避免负数。
        """
        return ((y * self.grid_w + x) * 4 + (d + 1)) * self.min_bend_steps + s

    def _decode(self, state: int) -> tuple[int, int, int, int]:
        """将 int 状态解码回 (x, y, dir, straight)。"""
        s = state % self.min_bend_steps
        rest = state // self.min_bend_steps
        d = rest % 4 - 1
        rest = rest // 4
        x = rest % self.grid_w
        y = rest // self.grid_w
        return (x, y, d, s)

    def _get_neighbors(
        self,
        pos: tuple[int, int],
        state: tuple[int, int],
        blocked: set[tuple[int, int]],
    ) -> list[tuple[int, int, int, int]]:
        """计算当前节点的有效邻居（满足边界/障碍/弯曲半径约束）。

        返回 ``[(nx, ny, d, new_straight), ...]``，其中 d 为方向编码
        （0=E, 1=W, 2=N, 3=S），new_straight 为该方向上的连续直行步数。
        """
        x, y = pos
        last_dir, straight = state
        moves = [(1, 0, 0), (-1, 0, 1), (0, 1, 2), (0, -1, 3)]
        neighbors: list[tuple[int, int, int, int]] = []
        for dx, dy, d in moves:
            nx, ny = x + dx, y + dy
            if not (0 <= nx < self.grid_w and 0 <= ny < self.grid_h):
                continue
            if self.obstacle[ny, nx] or (nx, ny) in blocked:
                continue
            # 弯曲半径约束：转弯前须直行 >= min_bend_steps 步
            is_turn = last_dir != -1 and d != last_dir
            new_straight = straight + 1 if d == last_dir else 1
            # 钳位 new_straight 到 min_bend_steps，避免状态空间无上限膨胀
            # （straight > min_bend_steps 后行为等价，无需区分）
            new_straight = min(new_straight, self.min_bend_steps)
            if is_turn and straight < self.min_bend_steps:
                continue
            neighbors.append((nx, ny, d, new_straight))
        return neighbors

    def _is_passable(self, x: int, y: int) -> bool:
        """检查网格点是否可通行（边界内 + 非障碍 + 非阻塞）。

        使用 ``self._route_blocked``（route() 期间缓存）降低参数个数。
        """
        if not (0 <= x < self.grid_w and 0 <= y < self.grid_h):
            return False
        if self.obstacle[y, x]:
            return False
        return (x, y) not in self._route_blocked

    def _jump(self, x: int, y: int, d: int, straight: int) -> list[tuple[int, int, int, int, int]]:
        """JPS-Bend 跳跃扩展（第一波A 步骤3，核心加速）。

        从 (x,y) 沿方向 d 跳跃，跳过无决策意义的直行中间节点，
        只返回跳跃终点（可转弯点/撞障碍前/到达目标）。

        来源: Harabor & Grastien, AAAI 2011,
        https://cdn.aaai.org/ojs/7994/7994-13-11522-1-2-20201228.pdf

        Returns:
            ``[(x, y, d, new_straight, steps), ...]``，steps 为跳跃步数。
        """
        dx, dy = self._DIR_VECTORS[d]
        results: list[tuple[int, int, int, int, int]] = []
        cx, cy = x, y
        steps = 0
        cur_straight = straight
        while True:
            cx += dx
            cy += dy
            steps += 1
            if not self._is_passable(cx, cy):
                break  # 撞障碍/边界，停止
            cur_straight = min(cur_straight + 1, self.min_bend_steps)
            # 到达目标
            if (cx, cy) == self._route_goal:
                results.append((cx, cy, d, cur_straight, steps))
                break
            # 可转弯点：straight >= min_bend_steps，生成转弯分叉
            if cur_straight >= self.min_bend_steps:
                results.append((cx, cy, d, cur_straight, steps))
        return results

    def _get_jump_successors(
        self, x: int, y: int, last_dir: int, straight: int
    ) -> list[tuple[int, int, int, int, int]]:
        """获取 JPS-Bend 后继节点（跳跃终点 + 转弯分叉）。

        对每个可能方向：
        - 若是当前方向：用 _jump 跳跃到可转弯点或撞障碍
        - 若是新方向（转弯）：须满足 straight >= min_bend_steps，
          然后从转弯点开始跳跃

        Returns:
            ``[(nx, ny, d, new_straight, steps), ...]``
        """
        successors: list[tuple[int, int, int, int, int]] = []
        for d in range(4):
            is_turn = last_dir != -1 and d != last_dir
            if is_turn and straight < self.min_bend_steps:
                continue  # 弯曲半径约束：未直行够不能转弯
            # 检查第一步是否可通行
            dx, dy = self._DIR_VECTORS[d]
            nx, ny = x + dx, y + dy
            if not self._is_passable(nx, ny):
                continue
            # 从 (nx, ny) 沿 d 跳跃
            jump_start_straight = 1 if is_turn else min(straight + 1, self.min_bend_steps)
            jumps = self._jump(nx, ny, d, jump_start_straight)
            # 调整 steps（_jump 内部 steps 从 0 开始，但第一步已走）
            for jx, jy, jd, js, jsteps in jumps:
                successors.append((jx, jy, jd, js, jsteps + 1))
        return successors

    def _reconstruct_path(
        self,
        came_from: dict[int, int],
        goal_state: int,
    ) -> list[tuple[int, int]]:
        """从 came_from 回溯重建路径（整数状态编码，第一波A 步骤2）。

        JPS-Bend 跳跃会跳过中间节点，回溯时需要补全直行段中间点。

        Args:
            came_from: int 状态 → int 前驱状态。
            goal_state: 终点状态编码。

        Returns:
            网格坐标列表 ``[(x, y), ...]``。
        """
        # 先回溯出状态序列
        states: list[tuple[int, int, int, int]] = []
        cur: int | None = goal_state
        while cur is not None:
            states.append(self._decode(cur))
            cur = came_from.get(cur)
        states.reverse()
        if not states:
            return []
        # JPS 跳跃跳过了中间节点，需要补全相邻状态间的直行段
        path: list[tuple[int, int]] = [(states[0][0], states[0][1])]
        for i in range(1, len(states)):
            px, py, pd, _ = states[i - 1]
            cx, cy, cd, _ = states[i]
            if pd == cd and pd >= 0:
                # 同方向直行段，补全中间点
                dx, dy = self._DIR_VECTORS[cd]
                steps = abs(cx - px) + abs(cy - py)
                for s in range(1, steps):
                    path.append((px + dx * s, py + dy * s))
            path.append((cx, cy))
        return path

    def _save_endpoints(self, start, goal):
        """保存起点/终点障碍标记并临时清除（器件端口可能在 bbox 内）。"""
        h, w = self.obstacle.shape
        # 边界检查：越界坐标钳位到合法范围
        s0 = max(0, min(start[0], w - 1))
        s1 = max(0, min(start[1], h - 1))
        g0 = max(0, min(goal[0], w - 1))
        g1 = max(0, min(goal[1], h - 1))
        orig_start = self.obstacle[s1, s0]
        orig_goal = self.obstacle[g1, g0]
        self.obstacle[s1, s0] = 0
        self.obstacle[g1, g0] = 0
        return orig_start, orig_goal

    def _restore_endpoints(self, start, goal, orig_start, orig_goal):
        """恢复起点/终点的原始障碍标记。"""
        h, w = self.obstacle.shape
        s0 = max(0, min(start[0], w - 1))
        s1 = max(0, min(start[1], h - 1))
        g0 = max(0, min(goal[0], w - 1))
        g1 = max(0, min(goal[1], h - 1))
        self.obstacle[s1, s0] = orig_start
        self.obstacle[g1, g0] = orig_goal

    def _astar_search(
        self, start: tuple[int, int], goal: tuple[int, int], start_state: int
    ) -> tuple[int, dict[int, int]]:
        """A* 主搜索循环（从 route 拆分，降低函数行数，规则 7.2）。

        Returns:
            (goal_state_enc, came_from)。goal_state_enc=-1 表示未找到路径。
        """
        eps = 1e-3
        h0 = self._heuristic_bend_aware(start, goal, -1, 0)
        # heap: (f, g, state_int) —— 整数状态编码减少 tuple 哈希开销
        open_h: list[tuple[float, int, int]] = []
        heapq.heappush(open_h, (h0 * (1 + eps), 0, start_state))
        g_score: dict[int, int] = {start_state: 0}
        came_from: dict[int, int] = {}
        while open_h:
            _f, g, cur_state = heapq.heappop(open_h)
            x, y, last_dir, straight = self._decode(cur_state)
            if (x, y) == goal:
                return cur_state, came_from
            # JPS-Bend 跳跃扩展（步骤3）
            for nx, ny, d, new_straight, steps in self._get_jump_successors(
                x, y, last_dir, straight
            ):
                new_state = self._encode(nx, ny, d, new_straight)
                ng = g + steps
                if ng < g_score.get(new_state, 1 << 30):
                    g_score[new_state] = ng
                    came_from[new_state] = cur_state
                    nh = self._heuristic_bend_aware((nx, ny), goal, d, new_straight)
                    nf = ng + nh * (1 + eps)
                    heapq.heappush(open_h, (nf, ng, new_state))
        return -1, came_from

    def route(
        self,
        start: tuple[int, int],
        goal: tuple[int, int],
        blocked: set[tuple[int, int]] | None = None,
    ) -> list[tuple[int, int]] | None:
        """A* 搜索路径（返回网格坐标列表，失败返回 None）。

        性能优化（第一波A，目标 627ms→50ms）：
        - 整数状态编码（步骤2）：dict 键从 4-tuple 改为 int
        - JPS-Bend 跳跃（步骤3）：跳过直行段中间节点
        - 紧致启发式（步骤1）：弯曲半径感知 + tie-breaker

        Args:
            start: 起点网格坐标。
            goal: 终点网格坐标。
            blocked: 额外阻塞点集合。

        Returns:
            网格坐标列表，失败返回 None。
        """
        self._route_goal = goal
        self._route_blocked = blocked or set()
        orig_start, orig_goal = self._save_endpoints(start, goal)
        start_state = self._encode(start[0], start[1], -1, 0)
        goal_state_enc, came_from = self._astar_search(start, goal, start_state)
        self._restore_endpoints(start, goal, orig_start, orig_goal)
        if goal_state_enc < 0:
            return None
        return self._reconstruct_path(came_from, goal_state_enc)


# ---------------------------------------------------------------------------
# 平台约束
# ---------------------------------------------------------------------------
PLATFORM_CONSTRAINTS = {
    "SOI": {"min_bend_radius_um": 5.0, "min_spacing_um": 1.0},
    "SiN": {"min_bend_radius_um": 50.0, "min_spacing_um": 2.0},
    "InP": {"min_bend_radius_um": 100.0, "min_spacing_um": 3.0},
    "LNOI": {"min_bend_radius_um": 30.0, "min_spacing_um": 2.0},
}


def get_platform_constraints(platform: str) -> dict:
    """获取平台波导约束（弯曲半径/间距，来自 spec.md 真实参数）。"""
    return PLATFORM_CONSTRAINTS.get(platform, PLATFORM_CONSTRAINTS["SOI"])


@dataclass
class RouteConnectionConfig:
    """单连接布线配置（栅格 + 画布 + 障碍 + 等长约束）。

    将 ``route_connection`` 的布线参数打包为单一配置对象，降低函数参数个数
    （规则 4.1：参数上限 7）。

    向后兼容：``route_connection(start, end, platform, config=None, **kwargs)``
    中未提供 config 时，旧式关键字参数（grid_size/canvas_w/canvas_h/obstacles/
    target_length_um）会自动转发到本 dataclass 构造。
    """

    grid_size: float = 1.0
    canvas_w: float = 1000.0
    canvas_h: float = 1000.0
    obstacles: list[tuple[float, float, float, float]] | None = None
    target_length_um: float | None = None


# 平台传播损耗（dB/cm），来自 SiEPIC EBeam PDK + spec.md 真实参数
# SOI: 3 dB/cm（SiEPIC e-beam 工艺典型值，iccsz.com 报告 2-3 dB/cm）
# SiN: 0.1 dB/cm（SiN 超低损耗平台）
# LNOI: 0.4 dB/cm（LNOI 薄膜铌酸锂）
_PLATFORM_LOSS_DB_CM = {"SOI": 3.0, "SiN": 0.1, "LNOI": 0.4}


def _build_router_for_platform(config: RouteConnectionConfig, platform: str) -> GridRouter:
    """根据配置与平台约束构建 GridRouter 并添加障碍。"""
    cons = get_platform_constraints(platform)
    grid_w = int(config.canvas_w / config.grid_size)
    grid_h = int(config.canvas_h / config.grid_size)
    router = GridRouter(
        grid_w=grid_w,
        grid_h=grid_h,
        grid_size=config.grid_size,
        constraints=RouterConstraints(
            min_bend_radius_um=cons["min_bend_radius_um"],
            min_spacing_um=cons["min_spacing_um"],
        ),
    )
    for box in config.obstacles or []:
        router.add_obstacle_box(*box)
    return router


def _grid_path_to_points(
    grid_path: list[tuple[int, int]] | None,
    config: RouteConnectionConfig,
    start: tuple[float, float],
    end: tuple[float, float],
) -> list[tuple[float, float]]:
    """将网格路径转换为画布坐标点，起终点对齐到精确坐标。"""
    if grid_path is None:
        raise RuntimeError(f"A* 布线失败：无法找到从 {start} 到 {end} 的可行路径")
    pts = [(g[0] * config.grid_size, g[1] * config.grid_size) for g in grid_path]
    if pts:
        pts[0] = start
        pts[-1] = end
    return pts


def route_connection(
    start: tuple[float, float],
    end: tuple[float, float],
    platform: str = "SOI",
    config: RouteConnectionConfig | None = None,
    **kwargs: float | list | None,
) -> WaveguidePath:
    """布线一条连接（A* + 弯曲/等长约束）。

    Args:
        start: 起点画布坐标 (x, y) μm。
        end: 终点画布坐标 (x, y) μm。
        platform: 工艺平台（决定弯曲半径/间距约束）。
        config: 布线配置（栅格/画布/障碍/等长）。未提供时从 kwargs 构建。
        **kwargs: 旧式关键字参数（grid_size/canvas_w/canvas_h/obstacles/
            target_length_um），向后兼容。

    Returns:
        ``WaveguidePath``（含折线点、长度、损耗）。

    Raises:
        RuntimeError: A* 搜索无法找到可行路径时。
    """
    if config is None:
        config = RouteConnectionConfig(**kwargs)
    router = _build_router_for_platform(config, platform)
    sg = (int(start[0] / config.grid_size), int(start[1] / config.grid_size))
    eg = (int(end[0] / config.grid_size), int(end[1] / config.grid_size))
    grid_path = router.route(sg, eg)
    pts = _grid_path_to_points(grid_path, config, start, end)
    if config.target_length_um is not None:
        cons = get_platform_constraints(platform)
        pts = equalize_length(pts, config.target_length_um, detour_step=cons["min_bend_radius_um"])
    loss_db_cm = _PLATFORM_LOSS_DB_CM.get(platform, 2.0)
    loss = path_loss(pts, loss_db_cm=loss_db_cm)
    return WaveguidePath(points=pts, length_um=path_length(pts), loss_db=loss)


# ---------------------------------------------------------------------------
# 命名兼容别名（便于上层统一以 ``WaveguideRouter`` 名称访问）
# ---------------------------------------------------------------------------
# 历史代码与文档中曾以 ``WaveguideRouter`` 作为布线器统一入口名称，实际实现
# 为 ``GridRouter``（A* 网格布线器）。此处提供别名以保持向后兼容，避免上层
# 调用方在重构后出现 ImportError。
WaveguideRouter = GridRouter
"""布线器统一别名（指向 GridRouter）。

上层代码可通过 ``from polaris.router.waveguide_router import WaveguideRouter``
访问，与文档/接口约定保持一致。
"""
