"""SiEPIC GDS 电路解析器 — 从真实 GDS 文件提取网表。

读取 SiEPIC EBeam PDK 格式的 GDS 文件，提取器件与连接信息，
转换为 PoLaRIS CircuitSpec。

SiEPIC GDS 格式（来源: SiEPIC_EBeam_PDK, MIT, UBC）:
- DEVREC layer (68,0): 器件识别层
  - Polygon: 器件边界框
  - Text: ``Lumerical_INTERCONNECT_component=<name>`` + ``Spice_param:<params>``
- PIN layer (69,0): 端口标记层
  - Path: 2 点路径标记端口位置与方向
  - Text: 端口名（如 ``pin1``/``pin2``/``opt_input``/``opt_output``）

来源:
- SiEPIC EBeam PDK: https://github.com/SiEPIC/SiEPIC_EBeam_PDK
- SiEPIC netlist extraction: https://github.com/SiEPIC/SiEPIC-Tools
- klayout.db API: https://www.klayout.de/doc-qt5/code/class_LayerInfo.html
"""

from __future__ import annotations

import logging
import re
from pathlib import Path

from polaris.data.specs import CircuitSpec, DeviceSpec
from polaris.pdk.siepic_mapping import siepic_to_polaris

logger = logging.getLogger(__name__)

# SiEPIC 标准 layer 编号
_DEVREC_LAYER = (68, 0)
_PIN_LAYER = (69, 0)

# 端口位置匹配容差（μm）
_PORT_MATCH_TOL = 2.0

# 忽略的非器件实例名前缀
_IGNORE_PREFIXES = ("ROUND_PATH", "LumericalINTERCONNECT_Laser", "LumericalINTERCONNECT_Detector",
                    "OpticalFibre", "TE1550_SubGC", "Waveguide_Route")


def _parse_spice_param(text: str) -> dict:
    """解析 ``Spice_param:wg_width=0.500u gap=0.100u`` 格式的参数字符串。

    Args:
        text: Spice_param 文本（含或不含 ``Spice_param:`` 前缀）。

    Returns:
        参数字典，值已去除 ``u`` 后缀并转为 float。
    """
    if "Spice_param:" in text:
        text = text.split("Spice_param:", 1)[1]
    elif "Spice_param=" in text:
        text = text.split("Spice_param=", 1)[1]
    params: dict[str, float | str] = {}
    for token in text.strip().split():
        if "=" in token:
            k, v = token.split("=", 1)
            v_clean = v.rstrip("u")
            try:
                params[k] = float(v_clean)
            except ValueError:
                params[k] = v_clean
    return params


def _extract_component_name(text: str) -> str | None:
    """从 DEVREC 文本中提取 ``Lumerical_INTERCONNECT_component=<name>`` 的器件名。

    Args:
        text: DEVREC 文本标签内容。

    Returns:
        器件名（如 ``ebeam_y_1550``），未找到返回 None。
    """
    match = re.search(r"Lumerical_INTERCONNECT_component=(\S+)", text)
    return match.group(1) if match else None


def _port_direction_from_path(pts: list[tuple[float, float]]) -> str:
    """根据 PIN Path 的两点方向推断端口朝向。

    Args:
        pts: Path 的两个端点 [(x1,y1), (x2,y2)]。

    Returns:
        方向字母: ``"N"``/``"S"``/``"E"``/``"W"``。
    """
    if len(pts) < 2:
        return "E"
    dx = pts[1][0] - pts[0][0]
    dy = pts[1][1] - pts[0][1]
    if abs(dx) > abs(dy):
        return "E" if dx > 0 else "W"
    return "N" if dy > 0 else "S"


def _is_device_instance(cell_name: str) -> bool:
    """判断实例是否为光子器件（非辅助图形）。

    Args:
        cell_name: 实例 cell 名称。

    Returns:
        True 如果是器件实例（非 ROUND_PATH/Laser/Detector 等辅助图形）。
    """
    return not cell_name.startswith(_IGNORE_PREFIXES)


def _apply_trans(trans, x: float, y: float, dbu: float = 1.0) -> tuple[float, float]:
    """手动应用 DCplxTrans 变换到点坐标。

    klayout Python 绑定中 ``DCplxTrans * DPoint`` 运算符不生效，
    需手动分解旋转/镜像/缩放/平移并应用。

    注意: ``RecursiveShapeIterator.dtrans()`` 返回的位移单位是数据库单位（dbu），
    需除以 dbu 转换为微米；``inst.cplx_trans`` 的位移已是微米，dbu=1.0 即可。

    Args:
        trans: ``klayout.db.DCplxTrans`` 变换对象。
        x: 点 x 坐标（μm）。
        y: 点 y 坐标（μm）。
        dbu: 数据库单位转微米因子（dtrans 需传入实际 dbu，cplx_trans 传 1.0）。

    Returns:
        变换后的 (x, y) 坐标元组。
    """
    # 分解变换：angle (度) + mirror + scale + disp
    angle = trans.angle  # 旋转角度（度）
    mirror = trans.is_mirror  # 是否镜像
    scale = trans.mag  # 缩放因子
    disp = trans.disp  # 平移向量 (DPoint)
    # dtrans() 的位移在 dbu 中，需转换为 μm
    dx = disp.x / dbu if dbu != 1.0 else disp.x
    dy = disp.y / dbu if dbu != 1.0 else disp.y
    # 应用缩放
    sx, sy = x * scale, y * scale
    # 应用镜像
    if mirror:
        sx = -sx
    # 应用旋转（角度转弧度）
    import math
    rad = math.radians(angle)
    cos_a = math.cos(rad)
    sin_a = math.sin(rad)
    rx = sx * cos_a - sy * sin_a
    ry = sx * sin_a + sy * cos_a
    # 应用平移
    return (rx + dx, ry + dy)


def load_gds_to_circuit(gds_path: str | Path) -> CircuitSpec:
    """从 SiEPIC GDS 文件提取电路规格。

    读取 GDS 文件，解析实例、DEVREC 和 PIN 层，提取器件与连接信息，
    转换为 PoLaRIS CircuitSpec。每个器件实例获得唯一名称（如 ``ebeam_gc_te1550_0``）。

    Args:
        gds_path: GDS 文件路径。

    Returns:
        CircuitSpec 对象，含器件列表与连接列表。

    Raises:
        FileNotFoundError: GDS 文件不存在。
        ImportError: klayout 未安装。
    """
    try:
        import klayout.db as db
    except ImportError as e:
        raise ImportError(
            "klayout 未安装，无法解析 GDS 文件。请运行: pip install klayout"
        ) from e

    gds_path = Path(gds_path)
    if not gds_path.exists():
        raise FileNotFoundError(f"GDS 文件不存在: {gds_path}")

    ly = db.Layout()
    ly.read(str(gds_path))
    top = ly.top_cells()[0]
    circuit_name = top.name
    dbu = ly.dbu

    logger.info("解析 GDS: %s (top cell: %s)", gds_path.name, circuit_name)

    # 1. 收集器件实例（cell name + transform → 唯一器件名）
    instances: list[dict] = []
    name_counter: dict[str, int] = {}
    for inst in top.each_inst():
        cell_name = inst.cell.name
        if not _is_device_instance(cell_name):
            continue
        # 唯一实例名: ebeam_gc_te1550_0, ebeam_gc_te1550_1, ...
        idx = name_counter.get(cell_name, 0)
        unique_name = f"{cell_name}_{idx}" if idx > 0 else cell_name
        name_counter[cell_name] = idx + 1
        trans = inst.cplx_trans
        # 实例 bbox（dbbox 已是微米单位，无需再乘 dbu）
        cell_bbox = inst.cell.dbbox()
        cx = (cell_bbox.left + cell_bbox.right) / 2
        cy = (cell_bbox.bottom + cell_bbox.top) / 2
        center = _apply_trans(trans, cx, cy)
        # 实例 bbox（在顶层坐标系中）
        bl = _apply_trans(trans, cell_bbox.left, cell_bbox.bottom)
        tr = _apply_trans(trans, cell_bbox.right, cell_bbox.top)
        instances.append({
            "unique_name": unique_name,
            "cell_name": cell_name,
            "center": center,
            "bbox": (min(bl[0], tr[0]), min(bl[1], tr[1]), max(bl[0], tr[0]), max(bl[1], tr[1])),
            "trans": trans,
            "params": {},
        })

    # 2. 从 DEVREC text 提取参数，匹配到最近的实例
    devrec_layer = ly.layer(_DEVREC_LAYER[0], _DEVREC_LAYER[1])
    devrec_texts: list[tuple[str, float, float]] = []
    for it in top.begin_shapes_rec(devrec_layer):
        s = it.shape()
        if s.is_text():
            trans = it.dtrans()
            txt = s.text.string
            raw = s.text_dpos
            px, py = _apply_trans(trans, raw.x, raw.y, dbu=dbu)
            devrec_texts.append((txt, px, py))

    # 解析 Spice_param 并匹配到最近的实例
    for txt, tx, ty in devrec_texts:
        if "Spice_param" in txt:
            params = _parse_spice_param(txt)
            best_dist = float("inf")
            best_idx = -1
            for i, inst in enumerate(instances):
                dist = ((inst["center"][0] - tx) ** 2 + (inst["center"][1] - ty) ** 2) ** 0.5
                if dist < best_dist:
                    best_dist = dist
                    best_idx = i
            if best_idx >= 0 and params:
                instances[best_idx]["params"].update(params)

    # 3. 提取 PIN 层端口（path + text）
    pin_layer = ly.layer(_PIN_LAYER[0], _PIN_LAYER[1])
    pin_paths: list[list[tuple[float, float]]] = []
    pin_texts: list[tuple[str, float, float]] = []
    for it in top.begin_shapes_rec(pin_layer):
        s = it.shape()
        trans = it.dtrans()
        if s.is_text():
            txt = s.text.string
            raw = s.text_dpos
            px, py = _apply_trans(trans, raw.x, raw.y, dbu=dbu)
            pin_texts.append((txt, px, py))
        elif s.is_path():
            dp = s.dpath
            pts: list[tuple[float, float]] = []
            for p in dp.each_point():
                px, py = _apply_trans(trans, p.x, p.y, dbu=dbu)
                pts.append((px, py))
            pin_paths.append(pts)

    # 4. 匹配 PIN text 到最近的 PIN path（构建端口）
    ports: list[dict] = []
    for name, tx, ty in pin_texts:
        best_dist = float("inf")
        best_path_pts: list[tuple[float, float]] = []
        for pts in pin_paths:
            for px, py in pts:
                dist = ((tx - px) ** 2 + (ty - py) ** 2) ** 0.5
                if dist < best_dist:
                    best_dist = dist
                    best_path_pts = pts
        if best_path_pts:
            mid_x = sum(p[0] for p in best_path_pts) / len(best_path_pts)
            mid_y = sum(p[1] for p in best_path_pts) / len(best_path_pts)
            direction = _port_direction_from_path(best_path_pts)
            ports.append({
                "name": name,
                "pos": (mid_x, mid_y),
                "direction": direction,
            })

    # 5. 匹配端口到最近的器件实例
    for port in ports:
        px, py = port["pos"]
        best_dist = float("inf")
        best_name: str | None = None
        for inst in instances:
            cx, cy = inst["center"]
            dist = ((px - cx) ** 2 + (py - cy) ** 2) ** 0.5
            if dist < best_dist:
                best_dist = dist
                best_name = inst["unique_name"]
        port["device_name"] = best_name

    # 6. 构建连接（同位置端口互连）
    connections: list[tuple[str, str, str, str]] = []
    used: set[int] = set()
    for i, p1 in enumerate(ports):
        if i in used or not p1.get("device_name"):
            continue
        for j, p2 in enumerate(ports):
            if j <= i or j in used or not p2.get("device_name"):
                continue
            if p1["device_name"] == p2["device_name"]:
                continue
            dist = ((p1["pos"][0] - p2["pos"][0]) ** 2 + (p1["pos"][1] - p2["pos"][1]) ** 2) ** 0.5
            if dist < _PORT_MATCH_TOL:
                connections.append((p1["device_name"], p1["name"], p2["device_name"], p2["name"]))
                used.add(i)
                used.add(j)
                break

    # 7. 构建 DeviceSpec 列表
    devices: list[DeviceSpec] = []
    for inst in instances:
        cell_name = inst["cell_name"]
        polaris_name = siepic_to_polaris(cell_name) or cell_name
        xmin, ymin, xmax, ymax = inst["bbox"]
        w = max(xmax - xmin, 1.0)
        h = max(ymax - ymin, 1.0)
        dev_ports = [
            (p["name"], 0.0, 0.0, p["direction"])
            for p in ports
            if p.get("device_name") == inst["unique_name"]
        ]
        devices.append(DeviceSpec(
            name=inst["unique_name"],
            device_type=polaris_name,
            width_um=w,
            height_um=h,
            ports=dev_ports,
            params=inst["params"],
        ))

    # 8. 计算画布尺寸
    all_x: list[float] = []
    all_y: list[float] = []
    for inst in instances:
        xmin, ymin, xmax, ymax = inst["bbox"]
        all_x.extend([xmin, xmax])
        all_y.extend([ymin, ymax])
    for p in ports:
        all_x.append(p["pos"][0])
        all_y.append(p["pos"][1])
    if all_x and all_y:
        canvas_w = max(all_x) - min(all_x) + 50.0
        canvas_h = max(all_y) - min(all_y) + 50.0
    else:
        canvas_w = canvas_h = 500.0

    circuit = CircuitSpec(
        name=circuit_name,
        devices=devices,
        connections=connections,
        canvas_w=max(canvas_w, 100.0),
        canvas_h=max(canvas_h, 100.0),
    )

    logger.info(
        "GDS 解析完成: %s (%d 器件, %d 连接, %d 端口)",
        circuit_name, len(circuit.devices), len(circuit.connections), len(ports),
    )
    return circuit


__all__ = ["load_gds_to_circuit"]
