# Copyright 2026 The Orbax Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Handles persistent storage logic (GCS/S3) for P2P checkpointing."""

from typing import Any, Sequence, final

from absl import logging
from etils import epath
import jax
import orbax.checkpoint as ocp
from orbax.checkpoint import args as args_lib
from orbax.checkpoint import checkpoint_manager
from orbax.checkpoint import checkpoint_utils
from orbax.checkpoint._src.multihost import multihost
from orbax.checkpoint._src.multihost import multislice
from orbax.checkpoint._src.serialization import type_handler_registry
from orbax.checkpoint._src.serialization import type_handlers
from orbax.checkpoint.experimental.emergency.p2p import args as p2p_args_lib
from orbax.checkpoint.experimental.emergency.p2p import constants
from orbax.checkpoint.experimental.emergency.p2p import options as options_lib
from orbax.checkpoint.experimental.emergency.p2p import policies
from orbax.checkpoint.experimental.emergency.p2p import utils

_PRIMARY_REPLICA_ID = 0
PyTree = Any


def _create_persistent_handler(
    mp_options: checkpoint_manager.MultiprocessingOptions,
    replica_axis_index: int,
    is_single_slice: bool,
) -> ocp.PyTreeCheckpointHandler:
  """Creates a PyTreeCheckpointHandler for persistent storage.

  Args:
    mp_options: Multiprocessing options for the checkpoint handler.
    replica_axis_index: The index of the replica axis in the mesh.
    is_single_slice: Whether the mesh is single-slice.

  Returns:
    A PyTreeCheckpointHandler configured for persistent storage.
  """
  handler = type_handlers.SingleReplicaArrayHandler(
      replica_axis_index=replica_axis_index,
      broadcast_memory_limit_bytes=1024 * 1024 * 1000,
      primary_host=mp_options.primary_host,
      replica_id=_PRIMARY_REPLICA_ID,
      use_replica_parallel=False,
  )
  if is_single_slice:
    handler = type_handlers.ArrayHandler(
        primary_host=mp_options.primary_host,
        replica_id=_PRIMARY_REPLICA_ID,
        use_replica_parallel=False,
    )
  registry = type_handler_registry.create_type_handler_registry(
      (
          jax.Array,
          handler,
      ),
  )
  return ocp.PyTreeCheckpointHandler(
      use_ocdbt=True,
      use_zarr3=True,
      multiprocessing_options=mp_options,
      type_handler_registry=registry,
  )


@final
class PersistentCheckpointManager:
  """Manages saving/restoring from slow persistent storage."""

  def __init__(
      self,
      directory: epath.PathLike,
      global_mesh: jax.sharding.Mesh,
      *,
      replica_axis_index: int,
      options: options_lib.CheckpointManagerOptions,
  ):
    self._directory = epath.Path(directory)
    self._global_mesh = global_mesh
    self._replica_axis_index = replica_axis_index
    self._process_index = multihost.process_index()
    self._replica_id = multislice.process_replica_id(
        self._process_index,
        self._global_mesh,
        replica_axis_index=self._replica_axis_index,
    )
    mp_options = checkpoint_manager.MultiprocessingOptions(
        primary_host=0,
        active_processes=None,
        barrier_sync_key_prefix='persistent_fallback',
    )

    internal_options = checkpoint_manager.CheckpointManagerOptions(
        create=False,
        multiprocessing_options=mp_options,
        step_name_format=options.step_name_format,
        save_decision_policy=policies.OffsetFixedIntervalPolicy(
            interval=options.persistent.save_interval_steps,
            offset=options.persistent.save_interval_offset_steps,
        ),
        max_to_keep=options.persistent.max_to_keep,
        enable_async_checkpointing=True,
    )

    item_handlers = dict(
        state=_create_persistent_handler(
            mp_options,
            self._replica_axis_index,
            multislice.replica_count(
                self._global_mesh, replica_axis_index=self._replica_axis_index
            )
            == 1,
        )
    )
    if utils.pygrain() is not None:
      item_handlers['data_iter'] = utils.pygrain().PyGrainCheckpointHandler()

    self._manager = checkpoint_manager.CheckpointManager(
        self._directory,
        options=internal_options,
        item_handlers=item_handlers,
    )

  @property
  def directory(self) -> epath.Path:
    return self._directory

  def all_steps(self, read: bool = False) -> Sequence[int]:
    return self._manager.all_steps(read)

  def latest_step(self) -> int | None:
    return self._manager.latest_step()

  def should_save(self, step: int) -> bool:
    return self._manager.should_save(step)

  def save(
      self,
      step: int,
      args: p2p_args_lib.Composite,
      *,
      force: bool = False,
  ) -> bool:
    return self._manager.save(step, args=args, force=force)

  def restore(
      self,
      step: int,
      args: p2p_args_lib.Composite,
  ) -> p2p_args_lib.Composite:
    """Restores a checkpoint from persistent storage.

    Args:
      step: The step number to restore.
      args: A Composite object containing the abstract state to restore.

    Returns:
      The restored state as a Composite object.
    """
    assert self._manager is not None
    logging.info(
        'Restoring step %s from persistent storage on slice %d...',
        step,
        self._replica_id,
    )
    abstract_state = args.state
    if isinstance(args.state, args_lib.PyTreeRestore):
      abstract_state = args.state.item

    def _get_sr_restore_args(x):
      if (
          multislice.replica_count(
              self._global_mesh, replica_axis_index=self._replica_axis_index
          )
          > 1
          and isinstance(x, jax.ShapeDtypeStruct)
          and isinstance(x.sharding, jax.sharding.NamedSharding)
      ):
        return type_handlers.SingleReplicaArrayRestoreArgs(
            sharding=x.sharding,
            global_shape=x.shape,
            dtype=x.dtype,
        )
      else:
        return checkpoint_utils.construct_restore_args(x)

    restore_args_tree = jax.tree.map(_get_sr_restore_args, abstract_state)

    restore_args_obj = args_lib.PyTreeRestore(
        item=abstract_state,
        restore_args=restore_args_tree,
    )
    restore_kwargs = {'state': restore_args_obj}
    if constants.DATA_ITER_KEY in args:
      restore_kwargs[constants.DATA_ITER_KEY] = args.data_iter
    return self._manager.restore(
        step, args=p2p_args_lib.Composite(**restore_kwargs)
    )

  def delete(self, step: int):
    self._manager.delete(step)

  def wait_until_finished(self):
    self._manager.wait_until_finished()

  def check_for_errors(self):
    self._manager.check_for_errors()

  def reload(self):
    """Reloads the internal checkpoint manager."""
    self._manager.reload()

  def close(self):
    self._manager.close()
